﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace library
{
    public class CADUsuario
    {
        public bool createUsuario(ENUsuario usu)
        {
            return true;
        }
        public bool updateUsuario(ENUsuario usu)
        {
            return true;
        }
        public bool deleteUsuario(ENUsuario usu)
        {
            return true;
        }
        public bool signIn(ENUsuario usu)
        {
            return true;
        }
        public bool readUsuario(ENUsuario usu)
        {
            return true;
        }
        public bool addOferta(bool admin)
        {
            return true;
        }
        public bool addDesarrollador(bool admin)
        {
            return true;
        }
        public bool addProducto(bool admin)
        {
            return true;
        }
        public bool deleteOferta(bool admin)
        {
            return true;
        }
        public bool deleteDesarrollador(bool admin)
        {
            return true;
        }
        public bool deleteProducto(bool admin)
        {
            return true;
        }
        public bool modifyOferta(bool admin)
        {
            return true;
        }
        public bool modifyDesarrollador(bool admin)
        {
            return true;
        }
        public bool modifyProducto(bool admin)
        {
            return true;
        }
    }
}
